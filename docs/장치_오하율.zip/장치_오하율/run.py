#!/usr/bin/env python3
"""
장치: 리추얼 기록 → 숫자 칸 + 능력별 문단 후보 생성기
같은 입력 → 같은 출력 (deterministic, AI 호출 없음)

사용법: python3 run.py
입력: input/ 폴더의 ritual.txt, attendance.txt, submissions.txt
출력: output/result.md
"""

import re
import os
from collections import defaultdict

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
INPUT_DIR = os.path.join(BASE_DIR, "input")
OUTPUT_DIR = os.path.join(BASE_DIR, "output")


def parse_ritual(filepath):
    """리추얼 기록 파싱"""
    with open(filepath, "r", encoding="utf-8") as f:
        text = f.read()

    # 기간 추출
    period_match = re.search(r"기간\s+(\d{4}-\d{2}-\d{2})\s*~\s*(\d{4}-\d{2}-\d{2})", text)
    start_date = period_match.group(1) if period_match else "미상"
    end_date = period_match.group(2) if period_match else "미상"

    # 날짜별 분리
    days = re.split(r"^## (\d{4}-\d{2}-\d{2})", text, flags=re.MULTILINE)
    day_data = []
    i = 1
    while i < len(days) - 1:
        date = days[i]
        content = days[i + 1]
        day_data.append({"date": date, "content": content})
        i += 2

    total_days = len(day_data)

    # 호흡 시간 추출
    breath_vals = []
    for d in day_data:
        m = re.search(r"호흡:\s*([\d.]+)", d["content"])
        if m:
            breath_vals.append(float(m.group(1)))

    # 강점 행동 실천 여부
    practiced = 0
    partial = 0
    not_done = 0
    for d in day_data:
        if "강점 행동: 실천했다" in d["content"] and "일부" not in d["content"].split("강점 행동:")[1].split("\n")[0]:
            practiced += 1
        elif "일부 실천" in d["content"]:
            partial += 1
        elif "못 했다" in d["content"]:
            not_done += 1

    # 동료 피드백 횟수
    gave_count = len(re.findall(r"동료.*에게 말한 장점", text))
    recv_count = len(re.findall(r"동료.*말해 준 내 장점", text))
    shared_count = len(re.findall(r"동료.*나눈 감사", text))

    # 늦은 작성 횟수
    late_count = len(re.findall(r"늦은 작성", text))

    # 능력별 키워드 매핑으로 관련 일화 추출
    ability_keywords = {
        "자기조절력": ["루틴", "반복", "꾸준", "집중", "계획", "습관", "정리", "체크", "관리", "규칙", "호흡", "명상", "절제", "조절"],
        "대인관계력": ["동료", "소통", "배려", "존중", "협력", "공유", "피드백", "관계", "도와", "감사", "신뢰", "친밀", "교류"],
        "자기동기력": ["목표", "도전", "성장", "배움", "학습", "발전", "실천", "의지", "열정", "노력", "성취", "자신감", "극복"],
    }

    ability_episodes = defaultdict(list)
    for d in day_data:
        content = d["content"]
        # "강점이 드러난 일화" 추출
        episode_match = re.search(r"강점이 드러난 일화:\s*(.+)", content)
        # "강점을 위해 노력하고 생각한 것" 추출
        effort_match = re.search(r"강점을 위해 노력하고 생각한 것:\s*(.+)", content)
        # "나에게 남기는 말" 추출
        self_msg_match = re.search(r"나에게 남기는 말:\s*(.+)", content)

        for ability, keywords in ability_keywords.items():
            for source, match in [("일화", episode_match), ("노력", effort_match), ("다짐", self_msg_match)]:
                if match:
                    text_line = match.group(1).strip()
                    if any(kw in text_line for kw in keywords) and len(text_line) > 15:
                        ability_episodes[ability].append({
                            "date": d["date"],
                            "source": source,
                            "text": text_line,
                        })

    return {
        "start_date": start_date,
        "end_date": end_date,
        "total_days": total_days,
        "breath_vals": breath_vals,
        "breath_avg": round(sum(breath_vals) / len(breath_vals), 1) if breath_vals else 0,
        "practiced": practiced,
        "partial": partial,
        "not_done": not_done,
        "practice_days": practiced + partial,
        "gave_feedback": gave_count,
        "recv_feedback": recv_count,
        "shared_thanks": shared_count,
        "late_count": late_count,
        "ability_episodes": dict(ability_episodes),
    }


def parse_attendance(filepath):
    """출석 기록 파싱"""
    with open(filepath, "r", encoding="utf-8") as f:
        text = f.read()

    data = {}
    for key in ["총_교육일수", "출석일수", "결석일수", "출석률"]:
        m = re.search(rf"{key}:\s*(\S+)", text)
        if m:
            data[key] = m.group(1)
    return data


def parse_submissions(filepath):
    """과제 제출 현황 파싱"""
    with open(filepath, "r", encoding="utf-8") as f:
        text = f.read()

    data = {}
    for key in ["총_과제수", "승인", "진행중", "미제출"]:
        m = re.search(rf"{key}:\s*(\S+)", text)
        if m:
            data[key] = m.group(1)
    return data


def generate_result(ritual, attendance, submissions):
    """결과 마크다운 생성"""
    lines = []
    lines.append("# 숫자 칸 + 능력별 문단 후보")
    lines.append(f"생성일: 입력 데이터 기준 ({ritual['start_date']} ~ {ritual['end_date']})")
    lines.append("")

    # ── 숫자 칸 ──
    lines.append("---")
    lines.append("## 1. 숫자 칸")
    lines.append("")
    lines.append("| 항목 | 숫자 | 출처 |")
    lines.append("|------|------|------|")
    lines.append(f"| 리추얼 연속 기록 | {ritual['total_days']}일 | 리추얼 기록 |")
    lines.append(f"| 출석률 | {attendance.get('출석률', 'N/A')} ({attendance.get('출석일수', '?')}/{attendance.get('총_교육일수', '?')}일) | 내 출석 기록 |")
    lines.append(f"| 호흡 명상 평균 | {ritual['breath_avg']}분 | 리추얼 기록 |")
    lines.append(f"| 강점 행동 실천 | {ritual['practice_days']}/{ritual['total_days']}일 ({round(ritual['practice_days']/ritual['total_days']*100)}%) | 리추얼 기록 |")
    lines.append(f"| 동료 피드백 교환 | {ritual['gave_feedback']}회 (내가 전달) | 리추얼 기록 |")
    lines.append(f"| 동료가 전한 감사 | {ritual['shared_thanks']}회 | 리추얼 기록 |")
    lines.append(f"| 과제 승인 | {submissions.get('승인', '?')}/{submissions.get('총_과제수', '?')}건 | 내 제출 현황 |")
    lines.append(f"| 늦은 작성 | {ritual['late_count']}회 | 리추얼 기록 |")
    lines.append("")

    # ── 능력별 문단 후보 ──
    lines.append("---")
    lines.append("## 2. 능력별 문단 후보")
    lines.append("")
    lines.append("> 아래는 리추얼 기록에서 키워드 기반으로 추출한 후보입니다.")
    lines.append("> 사이트에 반영할 문단은 본인이 선택합니다.")
    lines.append("")

    for ability in ["자기조절력", "대인관계력", "자기동기력"]:
        lines.append(f"### {ability}")
        lines.append("")
        episodes = ritual["ability_episodes"].get(ability, [])
        if not episodes:
            lines.append("- (해당 키워드와 일치하는 일화가 없습니다)")
        else:
            # 날짜순 정렬, 중복 제거
            seen = set()
            sorted_eps = sorted(episodes, key=lambda x: x["date"])
            count = 0
            for ep in sorted_eps:
                key = ep["text"][:30]
                if key not in seen and count < 5:
                    seen.add(key)
                    lines.append(f"- **[{ep['date']}]** ({ep['source']}) {ep['text']}")
                    count += 1
        lines.append("")

    # ── 고난과 짝짓기 ──
    lines.append("---")
    lines.append("## 3. 숫자와 고난 장면 짝짓기 후보")
    lines.append("")
    lines.append(f"- 늦은 작성 {ritual['late_count']}회에도 {ritual['total_days']}일 연속 기록을 유지한 것은,")
    lines.append(f"  기록이 늦어진 날에도 당일 내 반드시 완료하는 원칙을 지켰기 때문입니다. (출처: 리추얼 기록)")
    lines.append(f"- 강점 행동을 못 한 날이 {ritual['not_done']}일 있었지만,")
    lines.append(f"  나머지 {ritual['practice_days']}일은 실천 또는 일부 실천을 이어갔습니다. (출처: 리추얼 기록)")
    lines.append("")

    return "\n".join(lines)


def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    ritual_path = os.path.join(INPUT_DIR, "ritual.txt")
    attendance_path = os.path.join(INPUT_DIR, "attendance.txt")
    submissions_path = os.path.join(INPUT_DIR, "submissions.txt")

    for p in [ritual_path, attendance_path, submissions_path]:
        if not os.path.exists(p):
            print(f"[오류] 입력 파일이 없습니다: {p}")
            return

    ritual = parse_ritual(ritual_path)
    attendance = parse_attendance(attendance_path)
    submissions = parse_submissions(submissions_path)

    result = generate_result(ritual, attendance, submissions)

    output_path = os.path.join(OUTPUT_DIR, "result.md")
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(result)

    print(f"[완료] {output_path}")
    print(f"  - 리추얼 {ritual['total_days']}일, 호흡 평균 {ritual['breath_avg']}분")
    print(f"  - 강점 실천 {ritual['practice_days']}/{ritual['total_days']}일")
    print(f"  - 동료 피드백 {ritual['gave_feedback']}회")
    print(f"  - 과제 {submissions.get('승인', '?')}/{submissions.get('총_과제수', '?')}건 승인")


if __name__ == "__main__":
    main()
